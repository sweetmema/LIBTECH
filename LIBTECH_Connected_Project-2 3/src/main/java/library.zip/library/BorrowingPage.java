/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

/**
 *
 * @author mlew
 */
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.*;
import java.time.LocalDate;
import java.time.Month;

public class BorrowingPage extends JFrame {
    private int activeRole;
    private RoundedTextField txtStudentId, txtBookId;
    private JComboBox<String> cmbBorrowDay, cmbBorrowMonth, cmbBorrowYear;
    private JComboBox<String> cmbReturnDay, cmbReturnMonth, cmbReturnYear;

    public BorrowingPage(int role) {
        this.activeRole = role;
        setTitle("LIBTECH - BOOK BORROWING & RESERVATION");
        setSize(1024, 680); // Restored standard window height
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(1, 2));

        // --- LEFT BLUE PANEL ---
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(new Color(30, 30, 50));
        GridBagConstraints lg = new GridBagConstraints();
        JLabel sideHeader = new JLabel("<html><center>BORROWING<br>DEPARTMENT</center></html>");
        sideHeader.setFont(new Font("SansSerif", Font.BOLD, 26));
        sideHeader.setForeground(Color.WHITE);
        leftPanel.add(sideHeader, lg);

        // --- RIGHT PANEL FORM ---
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(new Color(245, 245, 240));
        
        // Inner container for the actual form elements
        JPanel formWrapper = new JPanel();
        formWrapper.setLayout(new BoxLayout(formWrapper, BoxLayout.Y_AXIS));
        formWrapper.setOpaque(false);

        // 1. MATCHING 260x260 LOGO
        try {
            java.net.URL imgUrl = getClass().getResource("/library/logo.png");
            if (imgUrl != null) {
                ImageIcon originalIcon = new ImageIcon(imgUrl);
                Image scaledImage = originalIcon.getImage().getScaledInstance(260, 260, Image.SCALE_SMOOTH);
                JLabel logoLabel = new JLabel(new ImageIcon(scaledImage));
                logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                formWrapper.add(logoLabel);
                formWrapper.add(Box.createVerticalStrut(15)); // Compact gap below logo
            }
        } catch (Exception e) {}

        // Standard size locked to 32px height to match Review/Manage fields exactly
        Dimension standardFieldSize = new Dimension(360, 32);
        Dimension standardLabelSize = new Dimension(360, 18);

        // 2. STUDENT ID
        JLabel lblStudent = new JLabel("Student ID:");
        forceSize(lblStudent, standardLabelSize);
        formWrapper.add(lblStudent);
        
        txtStudentId = new RoundedTextField(18); 
        setupField(txtStudentId, "e.g. 22500011", standardFieldSize); 
        formWrapper.add(txtStudentId);
        formWrapper.add(Box.createVerticalStrut(8));

        // 3. BOOK ID
        JLabel lblBook = new JLabel("Book ID:");
        forceSize(lblBook, standardLabelSize);
        formWrapper.add(lblBook);
        
        txtBookId = new RoundedTextField(18); 
        setupField(txtBookId, "e.g. 104", standardFieldSize); 
        formWrapper.add(txtBookId);
        formWrapper.add(Box.createVerticalStrut(8));

        // DATES SETUP
        String[] days = new String[31]; for(int i=0; i<31; i++) days[i] = String.format("%02d", i+1);
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        String[] years = {"2026", "2027", "2028", "2029", "2030"};

        // 4. BORROW DATE
        JLabel lblBorrow = new JLabel("Borrow Date:");
        forceSize(lblBorrow, standardLabelSize);
        formWrapper.add(lblBorrow);
        
        JPanel pnlBorrow = new JPanel(new GridLayout(1, 3, 5, 0)); 
        pnlBorrow.setOpaque(false);
        cmbBorrowDay = new JComboBox<>(days); cmbBorrowMonth = new JComboBox<>(months); cmbBorrowYear = new JComboBox<>(years);
        pnlBorrow.add(cmbBorrowDay); pnlBorrow.add(cmbBorrowMonth); pnlBorrow.add(cmbBorrowYear);
        forceSize(pnlBorrow, standardFieldSize);
        formWrapper.add(pnlBorrow);
        formWrapper.add(Box.createVerticalStrut(8));

        // 5. RETURN DATE
        JLabel lblReturn = new JLabel("Expected Return Date:");
        forceSize(lblReturn, standardLabelSize);
        formWrapper.add(lblReturn);
        
        JPanel pnlReturn = new JPanel(new GridLayout(1, 3, 5, 0)); 
        pnlReturn.setOpaque(false);
        cmbReturnDay = new JComboBox<>(days); cmbReturnMonth = new JComboBox<>(months); cmbReturnYear = new JComboBox<>(years);
        pnlReturn.add(cmbReturnDay); pnlReturn.add(cmbReturnMonth); pnlReturn.add(cmbReturnYear);
        forceSize(pnlReturn, standardFieldSize);
        formWrapper.add(pnlReturn);
        formWrapper.add(Box.createVerticalStrut(20));

        // 6. ACTION BUTTONS (Kept slightly thicker for prominence)
        RoundedButton btnSubmit = new RoundedButton("Submit System Reservation", 22, Color.BLACK, Color.WHITE);
        forceSize(btnSubmit, new Dimension(360, 42));
        formWrapper.add(btnSubmit);
        formWrapper.add(Box.createVerticalStrut(8));

        RoundedButton btnBack = new RoundedButton("Return to Dashboard", 20, Color.WHITE, Color.BLACK);
        forceSize(btnBack, new Dimension(360, 38));
        formWrapper.add(btnBack);

        // Action Logic
        btnSubmit.addActionListener(e -> {
            try {
                int studentId = Integer.parseInt(txtStudentId.getText().trim());
                int bookId = Integer.parseInt(txtBookId.getText().trim());
                LocalDate borrowDate = buildDate(cmbBorrowDay, cmbBorrowMonth, cmbBorrowYear);
                LocalDate returnDate = buildDate(cmbReturnDay, cmbReturnMonth, cmbReturnYear);
                boolean ok = new BorrowDAO().borrowBook(studentId, bookId, borrowDate, returnDate);
                JOptionPane.showMessageDialog(this, ok ? "Borrow transaction saved in database." : "Book not available or ID not found.");
            } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage()); }
        });
        btnBack.addActionListener(e -> { new HomePage(activeRole).setVisible(true); this.dispose(); });

        // Place form wrapper perfectly into right panel center grid
        rightPanel.add(formWrapper);
        
        add(leftPanel); 
        add(rightPanel);
    }

    private LocalDate buildDate(JComboBox<String> dayBox, JComboBox<String> monthBox, JComboBox<String> yearBox) {
        int day = Integer.parseInt(dayBox.getSelectedItem().toString());
        int year = Integer.parseInt(yearBox.getSelectedItem().toString());
        int month = monthBox.getSelectedIndex() + 1;
        return LocalDate.of(year, month, day);
    }

    private void setupField(JTextField f, String hint, Dimension size) {
        forceSize(f, size);
        f.setText(hint); 
        f.setForeground(Color.GRAY);
        f.addFocusListener(new FocusListener() {
            public void focusGained(FocusEvent e) { if (f.getText().equals(hint)) { f.setText(""); f.setForeground(Color.BLACK); } }
            public void focusLost(FocusEvent e) { if (f.getText().isEmpty()) { f.setText(hint); f.setForeground(Color.GRAY); } }
        });
    }

    private void forceSize(JComponent comp, Dimension size) {
        comp.setPreferredSize(size);
        comp.setMinimumSize(size);
        comp.setMaximumSize(size);
        comp.setAlignmentX(Component.CENTER_ALIGNMENT);
    }
}